from .celery_app import celery_app

@celery_app.task(name="fm.echo")
def echo(message: str) -> dict:
    return {"echo": message}

@celery_app.task(name="fm.publish_preview_zip", bind=True)
def publish_preview_zip(self, zip_b64: str, bucket: str, prefix: str, artifact_id: str) -> dict:
    import base64
    from datetime import datetime, timezone

    from .publish import upload_zip_to_prefix
    from .db import update_artifact_metadata

    started_at = datetime.now(timezone.utc).isoformat()

    # mark STARTED
    update_artifact_metadata(artifact_id, {
        "state": "STARTED",
        "started_at": started_at,
        "celery_task_id": self.request.id,
        "bucket": bucket,
        "prefix": prefix,
    })

    try:
        zip_bytes = base64.b64decode(zip_b64.encode("utf-8"))
        res = upload_zip_to_prefix(zip_bytes, bucket=bucket, prefix=prefix)

        finished_at = datetime.now(timezone.utc).isoformat()
        update_artifact_metadata(artifact_id, {
            "state": "SUCCESS",
            "finished_at": finished_at,
            "uploaded": res.get("uploaded", 0),
        })
        return {"ok": True, **res}

    except Exception as e:
        finished_at = datetime.now(timezone.utc).isoformat()
        update_artifact_metadata(artifact_id, {
            "state": "FAILURE",
            "finished_at": finished_at,
            "error": str(e),
        })
        raise

@celery_app.task(name="fm.long_demo", bind=True)
def long_demo(self, company_code: str, task_id: str, seconds: int = 60) -> dict:
    import time
    from datetime import datetime, timezone
    from .db import get_task_status, update_artifact_metadata  # reuse updater for demo logs if you want

    started = datetime.now(timezone.utc).isoformat()
    # mark running in DB
    from .db import _sync_dsn
    import psycopg, os
    dsn = _sync_dsn()
    with psycopg.connect(dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE tasks t
                SET status='running',
                    runtime_json = COALESCE(runtime_json,'{}'::jsonb) || jsonb_build_object('celery_task_id', to_jsonb(CAST(%s AS text)))
                FROM companies c
                WHERE c.id=t.company_id AND c.code=%s AND t.id=%s::uuid
                """,
                (self.request.id, company_code, task_id),
            )
        conn.commit()

    elapsed = 0
    while elapsed < seconds:
        status = get_task_status(company_code, task_id)
        if status == "cancel_requested":
            with psycopg.connect(dsn) as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        UPDATE tasks t
                        SET status='cancelled'
                        FROM companies c
                        WHERE c.id=t.company_id AND c.code=%s AND t.id=%s::uuid
                        """,
                        (company_code, task_id),
                    )
                conn.commit()
            return {"ok": False, "state": "CANCELLED", "elapsed": elapsed}

        if status == "pause_requested":
            # wait until status becomes queued/running again
            while True:
                time.sleep(1)
                status2 = get_task_status(company_code, task_id)
                if status2 != "pause_requested":
                    break

        time.sleep(1)
        elapsed += 1

    with psycopg.connect(dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE tasks t
                SET status='succeeded'
                FROM companies c
                WHERE c.id=t.company_id AND c.code=%s AND t.id=%s::uuid
                """,
                (company_code, task_id),
            )
        conn.commit()

    return {"ok": True, "state": "SUCCESS", "elapsed": elapsed, "started_at": started}

@celery_app.task(name="fm.long_demo", bind=True)
def long_demo(self, company_code: str, task_id: str, seconds: int = 60) -> dict:
    import time
    from datetime import datetime, timezone
    import psycopg

    from .db import _sync_dsn, get_task_control

    dsn = _sync_dsn()

    # mark running + store celery_task_id
    with psycopg.connect(dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE tasks t
                SET status='running',
                    runtime_json = COALESCE(runtime_json,'{}'::jsonb) || jsonb_build_object('celery_task_id', to_jsonb(CAST(%s AS text)))
                FROM companies c
                WHERE c.id=t.company_id AND c.code=%s AND t.id=%s::uuid
                """,
                (self.request.id, company_code, task_id),
            )
        conn.commit()

    started = datetime.now(timezone.utc).isoformat()
    elapsed = 0

    while elapsed < seconds:
        ctl = get_task_control(company_code, task_id) or {}
        if ctl.get("cancel") is True:
            with psycopg.connect(dsn) as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        UPDATE tasks t
                        SET status='cancelled'
                        FROM companies c
                        WHERE c.id=t.company_id AND c.code=%s AND t.id=%s::uuid
                        """,
                        (company_code, task_id),
                    )
                conn.commit()
            return {"ok": False, "state": "CANCELLED", "elapsed": elapsed}

        # pause loop
        while (get_task_control(company_code, task_id) or {}).get("pause") is True:
            time.sleep(1)

        time.sleep(1)
        elapsed += 1

    with psycopg.connect(dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE tasks t
                SET status='succeeded'
                FROM companies c
                WHERE c.id=t.company_id AND c.code=%s AND t.id=%s::uuid
                """,
                (company_code, task_id),
            )
        conn.commit()

    return {"ok": True, "state": "SUCCESS", "elapsed": elapsed, "started_at": started}
