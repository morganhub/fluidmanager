from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from .db import get_db

router = APIRouter()

@router.get("/companies/{company_code}/tasks/{task_id}")
async def get_task(company_code: str, task_id: UUID, db: AsyncSession = Depends(get_db)):
    row = (await db.execute(text("""
        SELECT t.id, t.title, t.status, t.priority, t.created_at, t.deadline_at, t.runtime_json, t.control_json
        FROM tasks t
        JOIN companies c ON c.id = t.company_id
        WHERE c.code = :company_code AND t.id = :task_id
        LIMIT 1
    """), {"company_code": company_code, "task_id": task_id})).mappings().first()

    if not row:
        raise HTTPException(status_code=404, detail="Task not found")

    return dict(row)

@router.post("/companies/{company_code}/tasks/{task_id}/reset")
async def reset_task_controls(
    company_code: str,
    task_id: UUID,
    db: AsyncSession = Depends(get_db),
):
    """
    Reset "control flags" to a clean state.
    Use when a task got stuck with pause/cancel flags.
    """
    res = await db.execute(text("""
        UPDATE tasks t
        SET control_json = jsonb_build_object('pause', false, 'cancel', false)
        FROM companies c
        WHERE c.id=t.company_id AND c.code=:company_code AND t.id=:task_id
        RETURNING t.id, t.control_json
    """), {"company_code": company_code, "task_id": task_id})

    row = res.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="Task not found")

    await db.commit()
    return dict(row)
    
@router.post("/companies/{company_code}/tasks/{task_id}/pause")
async def pause_task(company_code: str, task_id: UUID, db: AsyncSession = Depends(get_db)):
    res = await db.execute(text("""
        UPDATE tasks t
        SET control_json = COALESCE(t.control_json,'{}'::jsonb) || jsonb_build_object('pause', true)
        FROM companies c
        WHERE c.id=t.company_id AND c.code=:company_code AND t.id=:task_id
        RETURNING t.id, t.control_json
    """), {"company_code": company_code, "task_id": task_id})
    row = res.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="Task not found")
    await db.commit()
    return dict(row)

@router.post("/companies/{company_code}/tasks/{task_id}/resume")
async def resume_task(company_code: str, task_id: UUID, db: AsyncSession = Depends(get_db)):
    res = await db.execute(text("""
        UPDATE tasks t
        SET control_json = COALESCE(t.control_json,'{}'::jsonb)
          || jsonb_build_object('pause', false, 'cancel', false)
        FROM companies c
        WHERE c.id=t.company_id AND c.code=:company_code AND t.id=:task_id
        RETURNING t.id, t.control_json
    """), {"company_code": company_code, "task_id": task_id})
    row = res.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="Task not found")
    await db.commit()
    return dict(row)

@router.post("/companies/{company_code}/tasks/{task_id}/cancel")
async def cancel_task(company_code: str, task_id: UUID, db: AsyncSession = Depends(get_db)):
    res = await db.execute(text("""
        UPDATE tasks t
        SET control_json = COALESCE(t.control_json,'{}'::jsonb) || jsonb_build_object('cancel', true)
        FROM companies c
        WHERE c.id=t.company_id AND c.code=:company_code AND t.id=:task_id
        RETURNING t.id, t.control_json
    """), {"company_code": company_code, "task_id": task_id})
    row = res.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="Task not found")
    await db.commit()
    return dict(row)
