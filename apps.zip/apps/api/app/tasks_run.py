from __future__ import annotations

import json
from datetime import datetime, timezone
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from .celery_client import celery_app
from .db import get_db

router = APIRouter()


# ---------- Response models (React-friendly / stable shape) ----------

class JobOut(BaseModel):
    celery_task_id: str
    celery_task_name: str


class TaskOut(BaseModel):
    task_id: str
    status: str
    attempt_count: int | None = None
    max_attempts: int | None = None
    previous_celery_task_id: str | None = None
    last_retry_at: str | None = None


class RunLongDemoOut(BaseModel):
    company_code: str
    project_code: str
    task: TaskOut
    job: JobOut
    seconds: int


class RetryOut(BaseModel):
    company_code: str
    project_code: str
    task: TaskOut
    job: JobOut


# ---------- Endpoints ----------

@router.post(
    "/companies/{company_code}/projects/{project_code}/tasks/{task_id}/run/long-demo",
    response_model=RunLongDemoOut,
)
async def run_long_demo(
    company_code: str,
    project_code: str,
    task_id: UUID,
    seconds: int = Query(60, ge=1, le=3600),
    db: AsyncSession = Depends(get_db),
):
    # NOTE: pas de FOR UPDATE ici: on enqueue + update; si tu veux verrouiller, on peut.
    row = (await db.execute(text("""
        SELECT
            t.id,
            t.company_id,
            t.status,
            (SELECT p.code FROM projects p WHERE p.id = t.project_id) AS project_code,
            t.attempt_count,
            t.max_attempts
        FROM tasks t
        JOIN companies c ON c.id = t.company_id
        WHERE c.code = :company_code
          AND t.id = :task_id
        LIMIT 1
    """), {"company_code": company_code, "task_id": task_id})).mappings().first()

    if not row:
        raise HTTPException(status_code=404, detail="Task not found")

    if row["project_code"] is not None and row["project_code"] != project_code:
        raise HTTPException(status_code=409, detail="Task not in this project")

    task_name = "fm.long_demo"
    args = [company_code, str(task_id), int(seconds)]

    async with db.begin():
        # Reset control plane (pause/cancel=false) + nettoyer flags d’erreur
        await db.execute(text("""
            UPDATE tasks t
            SET control_json = COALESCE(t.control_json,'{}'::jsonb)
                  || jsonb_build_object('pause', false, 'cancel', false),
                should_stop = false,
                last_error = NULL,
                status = 'queued'
            FROM companies c
            WHERE c.id=t.company_id
              AND c.code=:company_code
              AND t.id=:task_id
        """), {"company_code": company_code, "task_id": task_id})

        # Enqueue Celery
        async_result = celery_app.send_task(task_name, args=args)

        # Stocker job spec dans runtime_json (retryable)
        await db.execute(text("""
            UPDATE tasks t
            SET runtime_json = COALESCE(runtime_json,'{}'::jsonb)
                || jsonb_build_object(
                    'celery_task_id', to_jsonb(CAST(:celery_id AS text)),
                    'celery_task_name', to_jsonb(CAST(:task_name AS text)),
                    'celery_args', jsonb_build_array(
                        to_jsonb(CAST(:company_code AS text)),
                        to_jsonb(CAST(:task_id AS text)),
                        to_jsonb(CAST(:seconds AS int))
                    )
                )
            FROM companies c
            WHERE c.id=t.company_id
              AND c.code=:company_code
              AND t.id=:task_id
        """), {
            "company_code": company_code,
            "task_id": str(task_id),
            "seconds": int(seconds),
            "task_name": task_name,
            "celery_id": async_result.id,
        })

        # Log event (optionnel mais très utile pour UI)
        await db.execute(text("""
            INSERT INTO task_events (company_id, task_id, event_type, actor_type, payload)
            VALUES (:company_id, :task_id, 'run', 'system', CAST(:payload AS jsonb))
        """), {
            "company_id": row["company_id"],
            "task_id": task_id,
            "payload": json.dumps({
                "celery_task_id": async_result.id,
                "celery_task_name": task_name,
                "celery_args": args,
                "seconds": int(seconds),
                "ts": datetime.now(timezone.utc).isoformat(),
            }),
        })

    return RunLongDemoOut(
        company_code=company_code,
        project_code=project_code,
        seconds=int(seconds),
        task=TaskOut(
            task_id=str(task_id),
            status="queued",
            attempt_count=row.get("attempt_count"),
            max_attempts=row.get("max_attempts"),
        ),
        job=JobOut(
            celery_task_id=async_result.id,
            celery_task_name=task_name,
        ),
    )


@router.post(
    "/companies/{company_code}/projects/{project_code}/tasks/{task_id}/retry",
    response_model=RetryOut,
)
async def retry_task(
    company_code: str,
    project_code: str,
    task_id: UUID,
    db: AsyncSession = Depends(get_db),
):
    now_iso = datetime.now(timezone.utc).isoformat()

    async with db.begin():
        # Lock task row (sans outer join)
        row = (await db.execute(text("""
            SELECT
                t.id,
                t.company_id,
                (SELECT p.code FROM projects p WHERE p.id = t.project_id) AS project_code,
                t.status,
                t.attempt_count,
                t.max_attempts,
                t.runtime_json
            FROM tasks t
            JOIN companies c ON c.id = t.company_id
            WHERE c.code = :company_code
              AND t.id = :task_id
            FOR UPDATE OF t
        """), {"company_code": company_code, "task_id": task_id})).mappings().first()

        if not row:
            raise HTTPException(status_code=404, detail="Task not found")

        if row["project_code"] is not None and row["project_code"] != project_code:
            raise HTTPException(status_code=409, detail="Task not in this project")

        if row["status"] in ("done", "canceled"):
            raise HTTPException(status_code=409, detail=f"Cannot retry a task in status={row['status']}")

        if row["attempt_count"] >= row["max_attempts"]:
            raise HTTPException(status_code=409, detail="Max attempts reached")

        runtime = row["runtime_json"] or {}
        task_name = runtime.get("celery_task_name")
        args = runtime.get("celery_args")
        kwargs = runtime.get("celery_kwargs") or {}

        if not task_name or args is None:
            raise HTTPException(
                status_code=409,
                detail="Missing job spec in runtime_json (expected celery_task_name + celery_args)"
            )

        previous_celery_id = runtime.get("celery_task_id")

        # Enqueue new job
        async_result = celery_app.send_task(task_name, args=args, kwargs=kwargs)

        # Update task atomiquement (queued + reset control + attempts + runtime) + nettoyer flags
        updated = (await db.execute(text("""
            UPDATE tasks
            SET control_json = COALESCE(control_json,'{}'::jsonb)
                  || jsonb_build_object('pause', false, 'cancel', false),
                should_stop = false,
                last_error = NULL,
                attempt_count = attempt_count + 1,
                status = 'queued',
                runtime_json = COALESCE(runtime_json,'{}'::jsonb)
                  || jsonb_strip_nulls(
                        jsonb_build_object(
                            'previous_celery_task_id', to_jsonb(CAST(:prev_celery_id AS text)),
                            'celery_task_id', to_jsonb(CAST(:new_celery_id AS text)),
                            'last_retry_at', to_jsonb(CAST(:now_iso AS text))
                        )
                     )
            WHERE id = :task_id
              AND attempt_count < max_attempts
            RETURNING company_id, attempt_count, max_attempts
        """), {
            "task_id": task_id,
            "prev_celery_id": previous_celery_id,   # IMPORTANT: None -> NULL (pas de "")
            "new_celery_id": async_result.id,
            "now_iso": now_iso,
        })).mappings().first()

        if not updated:
            raise HTTPException(status_code=409, detail="Retry refused (max_attempts reached)")

        # Log event (payload JSONB stable)
        await db.execute(text("""
            INSERT INTO task_events (company_id, task_id, event_type, actor_type, payload)
            VALUES (:company_id, :task_id, 'retry', 'system', CAST(:payload AS jsonb))
        """), {
            "company_id": updated["company_id"],
            "task_id": task_id,
            "payload": json.dumps({
                "previous_celery_task_id": previous_celery_id,
                "celery_task_id": async_result.id,
                "celery_task_name": task_name,
                "celery_args": args,
                "celery_kwargs": kwargs,
                "attempt_count": updated["attempt_count"],
                "max_attempts": updated["max_attempts"],
                "ts": now_iso,
            }),
        })

    return RetryOut(
        company_code=company_code,
        project_code=project_code,
        task=TaskOut(
            task_id=str(task_id),
            status="queued",
            attempt_count=updated["attempt_count"],
            max_attempts=updated["max_attempts"],
            previous_celery_task_id=previous_celery_id,
            last_retry_at=now_iso,
        ),
        job=JobOut(
            celery_task_id=async_result.id,
            celery_task_name=task_name,
        ),
    )
